setwd("C:\\Users\\IT24104216\\Desktop\\IT24104216")
branch_data <- read.table("Exercise.txt", header = TRUE, sep = "")
boxplot(branch_data$Sales, main = "Boxplot for Sales", ylab = "Sales")
summary(branch_data$Advertising)
IQR(branch_data$Advertising)
get_outliers <- function(z) {
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  ub <- q3 + 1.5 * iqr
  lb <- q1 - 1.5 * iqr
  outliers <- z[z < lb | z > ub]
  return(outliers)
}

get_outliers(branch_data$Years)

